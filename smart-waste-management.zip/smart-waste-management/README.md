# SmartBin Cloud - Cloud-Based Smart Waste Management

IoT bin sensors + a cloud API + a live dashboard that tells collection trucks **which bins to visit and in what order**, instead of emptying every bin on a fixed schedule.

## 1. Abstract

Municipal waste collection usually follows fixed routes, so trucks visit half-empty bins while others overflow. This project fits each bin with an ultrasonic fill-level sensor (ESP32). Readings are uploaded to a cloud REST API, stored, analysed for alerts (overflow, fire, low battery), and used to compute an optimized multi-trip collection route. A web dashboard shows live bin status, fill-level history, predicted time-to-full, and the planned routes with the distance saved versus a fixed route.

## 2. Architecture

```
 +-----------------+   HTTPS/JSON    +--------------------------------------+      +---------------------+
 | ESP32 bin node  | --------------> |  Cloud API (Flask + gunicorn)        | <--> | Web dashboard       |
 | HC-SR04 + DHT22 |  X-API-Key      |  - telemetry ingestion + validation  |      | Leaflet map         |
 | battery monitor |                 |  - alert engine (overflow/fire/batt) |      | Chart.js history    |
 +-----------------+                 |  - fill-time prediction              |      | route planner UI    |
        ^                            |  - CVRP route optimizer              |      +---------------------+
        |  same API                  |  - SQLite (bins/readings/alerts)     |
 +-----------------+                 +--------------------------------------+
 | Python simulator|  (no hardware needed - 24 virtual bins)
 +-----------------+
```

## 3. Modules

| Module | Folder | What it does |
|---|---|---|
| IoT firmware | `firmware/esp32_bin_sensor/` | Median-filtered ultrasonic reading, DHT22 temperature, battery %, Wi-Fi upload, deep sleep |
| Device simulator | `simulator/simulator.py` | Posts realistic readings for all bins (faster-than-real-time clock) |
| Backend API | `backend/app.py`, `database.py` | REST API, auth, SQLite storage, alerts, prediction |
| Route optimizer | `backend/routing.py` | Threshold selection, capacity-aware trips, nearest-neighbour + 2-opt |
| Dashboard | `frontend/` | Live map, stats, alerts, charts, route planner |
| Tests | `tests/` | Routing and API tests (pytest) |

## 4. Quick start

Requires Python 3.9+.

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt

python backend/app.py                # http://localhost:5000  (24 demo bins are seeded automatically)
```

Open <http://localhost:5000>. Then:

1. Click **Optimize route** - see color-coded truck trips, stop order, total km and % saved.
2. Click **+6 hours** - virtual time advances, bins fill up, alerts appear.
3. Click a bin - see its fill history and predicted time-to-full.
4. **Mark this route as collected** - bins reset to 0% and alerts clear.

Optional: run the IoT simulator in a second terminal so data streams in continuously:

```bash
python simulator/simulator.py --url http://localhost:5000 --interval 2 --auto-collect
```

Run the tests:

```bash
pytest -q
```

### Docker

```bash
docker compose up --build        # http://localhost:5000
```

Set a real `API_KEY` in `docker-compose.yml` first.

## 5. API reference

Write endpoints used by devices need the header `X-API-Key: <API_KEY>` (default `dev-key`, set the `API_KEY` environment variable in production).

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/api/health` | - | Liveness check |
| GET | `/api/bins` | - | All bins with fill %, volume, status, `hours_to_full` |
| POST | `/api/bins` | key | Register a bin `{id, name, lat, lng, capacity_l}` |
| GET | `/api/bins/<id>/history?limit=48` | - | Time series of readings |
| POST | `/api/telemetry` | key | `{bin_id, fill_level, temperature, battery, timestamp?}` |
| GET | `/api/alerts?status=open\|all` | - | Overflow / fire / low-battery alerts |
| GET | `/api/stats` | - | Fleet KPIs |
| GET | `/api/route?threshold=70&capacity=6000` | - | Optimized collection plan |
| POST | `/api/bins/<id>/collect` | - | Mark one bin emptied |
| POST | `/api/collect` | - | Mark many bins emptied `{bin_ids: [...]}` |
| POST | `/api/simulate/step` | - | Demo: advance virtual time `{hours}` |
| POST | `/api/seed` | - | Demo: reset database to sample data |

Example device upload:

```bash
curl -X POST http://localhost:5000/api/telemetry \
  -H "Content-Type: application/json" -H "X-API-Key: dev-key" \
  -d '{"bin_id":"BIN-001","fill_level":83.5,"temperature":29.1,"battery":78}'
```

The demo-only endpoints (`collect`, `simulate`, `seed`) are unauthenticated for ease of demonstration. In production, put them behind user authentication (for example JWT for dispatchers) and remove `simulate` and `seed`.

## 6. Key algorithms

**Fill level (firmware).** `fill% = (bin_height - distance) / (bin_height - deadzone) * 100`, using the median of 7 ultrasonic samples to reject spikes.

**Alert rules.** OVERFLOW at 90% fill (auto-clears below 50%), FIRE at 60 C, LOW_BATTERY at 15%. At most one open alert per type per bin.

**Time-to-full prediction.** Linear fit over the latest filling cycle (readings since the last collection): `hours = (100 - fill) / slope`.

**Route optimization (capacitated vehicle routing).**
1. *Demand-based selection* - only bins at or above the fill threshold are collected.
2. *Trip construction* - nearest-neighbour from the depot; a new trip starts when the next bin would exceed truck capacity.
3. *Improvement* - 2-opt local search on every trip (reverses segments while total haversine distance decreases).
4. *Benchmark* - compares total distance with a fixed route that visits every bin, reporting % saved.

Complexity: nearest-neighbour is O(n^2) and each 2-opt pass is O(n^2) per trip, which is fine for city-scale fleets of hundreds of bins. For thousands of bins, replace this module with OR-Tools or a MILP solver; the API contract stays the same.

## 7. Hardware (ESP32 node)

| Part | Purpose | Pin |
|---|---|---|
| ESP32 DevKit v1 | MCU + Wi-Fi | - |
| HC-SR04 | fill distance | TRIG GPIO5, ECHO GPIO18 (via 1k/2k divider to 3.3 V) |
| DHT22 | internal temperature (fire detection) | GPIO4 + 10k pull-up |
| Li-ion + 2 x 100k | battery level | GPIO34 |

Edit the Wi-Fi credentials, `SERVER_URL`, `API_KEY` and `BIN_ID` at the top of `esp32_bin_sensor.ino`, register the bin through `POST /api/bins`, and flash with the Arduino IDE. The node wakes every 15 minutes, uploads, and deep-sleeps to save battery.

## 8. Deploying to the cloud

The app is a single container that listens on port 5000 and stores data in the `/data` volume.

- **AWS EC2 / Lightsail / Azure VM / GCP Compute Engine:** install Docker, `docker compose up -d`, open port 5000 (or put Nginx with a TLS certificate in front).
- **AWS App Runner / Azure Container Apps / Google Cloud Run:** deploy the Dockerfile. Mount a persistent volume or migrate SQLite to a managed database (see below).
- Always serve over HTTPS and set a strong `API_KEY`.

## 9. Future scope

- Replace SQLite with PostgreSQL (Amazon RDS / Cloud SQL) for multiple API instances; MQTT (AWS IoT Core / Azure IoT Hub) for device ingestion.
- Per-device API keys or X.509 certificates; user accounts and roles for dispatchers.
- Road-network distances (OSRM / Google Directions) instead of straight-line haversine.
- Machine-learning fill forecasting by weekday, weather and events; time windows and multiple trucks.
- Driver mobile app with turn-by-turn navigation and proof of collection.

## 10. Project structure

```
smart-waste-management/
|-- backend/        app.py  database.py  routing.py
|-- frontend/       index.html  style.css  app.js
|-- simulator/      simulator.py
|-- firmware/       esp32_bin_sensor/esp32_bin_sensor.ino
|-- tests/          conftest.py  test_api.py  test_routing.py
|-- Dockerfile  docker-compose.yml  requirements*.txt  README.md
```

Map tiles are (c) OpenStreetMap contributors. Leaflet and Chart.js are loaded from public CDNs, so the dashboard needs internet access.
