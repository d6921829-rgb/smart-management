#!/usr/bin/env python3
"""IoT device simulator - behaves like a fleet of ESP32 bin sensors.

Every tick each simulated bin posts fill level, temperature and battery to the
cloud API.  Simulated time runs faster than real time (--hours-per-tick) so the
dashboard shows realistic fill curves within a minute or two.

Usage:
    python simulator/simulator.py --url http://localhost:5000 --interval 2
"""
import argparse
import json
import random
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone


def call(url, method="GET", payload=None, api_key=None):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if api_key:
        req.add_header("X-API-Key", api_key)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode())


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--url", default="http://localhost:5000", help="API base URL")
    p.add_argument("--api-key", default="dev-key", help="device API key (X-API-Key)")
    p.add_argument("--interval", type=float, default=2.0, help="real seconds between ticks")
    p.add_argument("--hours-per-tick", type=float, default=0.5, help="simulated hours per tick")
    p.add_argument("--auto-collect", action="store_true",
                   help="simulate a truck emptying bins that reach 98%%")
    p.add_argument("--ticks", type=int, default=0, help="stop after N ticks (0 = run forever)")
    args = p.parse_args()
    base = args.url.rstrip("/")

    try:
        bins = call(f"{base}/api/bins")
    except (urllib.error.URLError, OSError) as exc:
        sys.exit(f"Cannot reach {base}: {exc}")
    if not bins:
        sys.exit("No bins registered. Start the backend (it seeds demo bins) or POST /api/bins.")

    rng = random.Random()
    state = {
        b["id"]: {
            "fill": b["fill_level"],
            "temp": b["temperature"],
            "battery": b["battery"],
            "rate": rng.uniform(1.5, 4.5),  # % per simulated hour
        }
        for b in bins
    }
    clock = max(datetime.fromisoformat(b["last_seen"]) for b in bins if b["last_seen"])
    print(f"Simulating {len(state)} bins against {base} (Ctrl+C to stop)")

    tick = 0
    try:
        while args.ticks == 0 or tick < args.ticks:
            tick += 1
            clock += timedelta(hours=args.hours_per_tick)
            ts = clock.astimezone(timezone.utc).isoformat(timespec="seconds")
            sent = 0
            for bin_id, s in state.items():
                s["fill"] = min(100.0, s["fill"] + s["rate"] * args.hours_per_tick * rng.uniform(0.7, 1.3))
                s["temp"] = min(45.0, max(20.0, s["temp"] + rng.uniform(-0.6, 0.6)))
                s["battery"] = max(0.0, s["battery"] - 0.02 * args.hours_per_tick)
                if rng.random() < 0.002:  # rare fire event
                    s["temp"] = 72.0
                payload = {
                    "bin_id": bin_id,
                    "fill_level": round(s["fill"], 1),
                    "temperature": round(s["temp"], 1),
                    "battery": round(s["battery"], 1),
                    "timestamp": ts,
                }
                try:
                    call(f"{base}/api/telemetry", "POST", payload, args.api_key)
                    sent += 1
                except urllib.error.HTTPError as exc:
                    print(f"  {bin_id}: HTTP {exc.code} {exc.read().decode()[:80]}")
                except (urllib.error.URLError, OSError) as exc:
                    print(f"  {bin_id}: network error {exc}")
                if args.auto_collect and s["fill"] >= 98:
                    try:
                        call(f"{base}/api/bins/{bin_id}/collect", "POST", {})
                        s["fill"], s["temp"] = 0.0, 28.0
                        print(f"  truck emptied {bin_id}")
                    except (urllib.error.URLError, OSError):
                        pass
            print(f"tick {tick}: sent {sent}/{len(state)} readings @ {ts}")
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
