"""SQLite persistence layer and demo-data seeding."""
import os
import random
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone

DB_PATH = os.environ.get(
    "WASTE_DB",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "waste.db"),
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS bins (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    lat         REAL NOT NULL,
    lng         REAL NOT NULL,
    capacity_l  REAL NOT NULL DEFAULT 1100,
    fill_level  REAL NOT NULL DEFAULT 0,
    temperature REAL NOT NULL DEFAULT 28,
    battery     REAL NOT NULL DEFAULT 100,
    sim_rate    REAL NOT NULL DEFAULT 2.0,   -- demo only: % fill gained per hour
    last_seen   TEXT
);
CREATE TABLE IF NOT EXISTS readings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    bin_id      TEXT NOT NULL REFERENCES bins(id) ON DELETE CASCADE,
    fill_level  REAL NOT NULL,
    temperature REAL NOT NULL,
    battery     REAL NOT NULL,
    ts          TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_readings_bin_ts ON readings(bin_id, ts);
CREATE TABLE IF NOT EXISTS alerts (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    bin_id    TEXT NOT NULL REFERENCES bins(id) ON DELETE CASCADE,
    type      TEXT NOT NULL,                 -- OVERFLOW | FIRE | LOW_BATTERY
    message   TEXT NOT NULL,
    ts        TEXT NOT NULL,
    resolved  INTEGER NOT NULL DEFAULT 0
);
"""

# (name, lat, lng) - sample public bin locations around Chennai
DEMO_BINS = [
    ("T. Nagar Bus Terminus", 13.0418, 80.2341),
    ("Anna Nagar Tower Park", 13.0850, 80.2101),
    ("Adyar Signal", 13.0012, 80.2565),
    ("Mylapore Tank", 13.0368, 80.2676),
    ("Egmore Station", 13.0732, 80.2609),
    ("Besant Nagar Beach", 13.0002, 80.2668),
    ("Guindy Industrial Estate", 13.0067, 80.2206),
    ("Velachery Main Road", 12.9815, 80.2180),
    ("Kodambakkam Junction", 13.0521, 80.2255),
    ("Nungambakkam High Road", 13.0569, 80.2425),
    ("Perambur Market", 13.1182, 80.2339),
    ("Tondiarpet Depot Road", 13.1260, 80.2880),
    ("Washermanpet Market", 13.1143, 80.2870),
    ("Kilpauk Garden", 13.0828, 80.2410),
    ("Vadapalani Temple", 13.0500, 80.2121),
    ("Triplicane High Road", 13.0569, 80.2790),
    ("Marina Beach Promenade", 13.0500, 80.2824),
    ("Chetpet Lake", 13.0732, 80.2420),
    ("Purasawalkam Market", 13.0827, 80.2570),
    ("Royapettah Clock Tower", 13.0535, 80.2644),
    ("Ashok Nagar 4th Avenue", 13.0373, 80.2123),
    ("Saidapet Bridge", 13.0213, 80.2231),
    ("Thiruvanmiyur Beach", 12.9830, 80.2594),
    ("Porur Junction", 13.0382, 80.1565),
]


@contextmanager
def connect():
    """Open a connection, commit on success, roll back on error, always close."""
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    folder = os.path.dirname(DB_PATH)
    if folder:
        os.makedirs(folder, exist_ok=True)
    with connect() as conn:
        conn.executescript(SCHEMA)


def count_bins():
    with connect() as conn:
        return conn.execute("SELECT COUNT(*) FROM bins").fetchone()[0]


def seed_demo():
    """Insert 24 demo bins with 24 h of rising fill history."""
    rng = random.Random(42)
    now = datetime.now(timezone.utc).replace(microsecond=0)
    with connect() as conn:
        for i, (name, lat, lng) in enumerate(DEMO_BINS, start=1):
            bin_id = f"BIN-{i:03d}"
            fill = round(rng.uniform(8, 98), 1)
            rate = round(rng.uniform(1.5, 4.5), 2)
            temp = round(rng.uniform(25, 34), 1)
            battery = round(rng.uniform(45, 100), 1)
            conn.execute(
                "INSERT INTO bins (id, name, lat, lng, capacity_l, fill_level, temperature,"
                " battery, sim_rate, last_seen) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (bin_id, name, lat, lng, 1100, fill, temp, battery, rate, now.isoformat()),
            )
            for h in range(24, -1, -1):
                ts = (now - timedelta(hours=h)).isoformat()
                val = round(max(0.0, fill - rate * h), 1)
                conn.execute(
                    "INSERT INTO readings (bin_id, fill_level, temperature, battery, ts)"
                    " VALUES (?,?,?,?,?)",
                    (bin_id, val, temp, battery, ts),
                )
            if fill >= 90:
                conn.execute(
                    "INSERT INTO alerts (bin_id, type, message, ts) VALUES (?,?,?,?)",
                    (bin_id, "OVERFLOW", f"Bin is {fill:.0f}% full - collect immediately",
                     now.isoformat()),
                )


def reset_and_seed():
    with connect() as conn:
        conn.executescript(
            "DROP TABLE IF EXISTS alerts; DROP TABLE IF EXISTS readings;"
            " DROP TABLE IF EXISTS bins;"
        )
    init_db()
    seed_demo()
