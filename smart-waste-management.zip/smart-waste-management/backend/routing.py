"""Route optimization for waste collection trucks.

Algorithm
---------
1. Select bins whose fill level is >= threshold (smart, demand-based pickup).
2. Build capacity-aware trips with a nearest-neighbour heuristic
   (a truck never carries more than `truck_capacity_l` litres per trip).
3. Improve every trip with 2-opt local search (Capacitated VRP heuristic).
4. Compare against a "fixed daily route" baseline that visits every bin.
"""
import math

DEPOT = {"name": "Central Depot (Royapuram)", "lat": 13.1067, "lng": 80.2954}


def coord(node):
    return (node["lat"], node["lng"])


def haversine_km(a, b):
    """Great-circle distance between two (lat, lng) tuples in km."""
    r = 6371.0
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    dlat, dlon = lat2 - lat1, lon2 - lon1
    h = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def path_length(nodes):
    return sum(haversine_km(coord(nodes[i]), coord(nodes[i + 1])) for i in range(len(nodes) - 1))


def two_opt(nodes):
    """2-opt improvement. `nodes` must start and end at the depot."""
    best = nodes[:]
    best_len = path_length(best)
    improved = True
    while improved:
        improved = False
        for i in range(1, len(best) - 2):
            for k in range(i + 1, len(best) - 1):
                cand = best[:i] + best[i:k + 1][::-1] + best[k + 1:]
                cand_len = path_length(cand)
                if cand_len < best_len - 1e-9:
                    best, best_len, improved = cand, cand_len, True
    return best


def optimize_routes(bins, threshold=70, truck_capacity_l=3000, depot=DEPOT):
    pending = []
    for b in bins:
        if b["fill_level"] >= threshold:
            item = dict(b)
            item["load_l"] = round(b["capacity_l"] * b["fill_level"] / 100.0, 1)
            pending.append(item)
    selected_count = len(pending)

    trips = []
    while pending:
        trip, load, cur = [], 0.0, depot
        while pending:
            fits = [b for b in pending if not trip or load + b["load_l"] <= truck_capacity_l]
            if not fits:
                break
            nxt = min(fits, key=lambda b: haversine_km(coord(cur), coord(b)))
            trip.append(nxt)
            pending.remove(nxt)
            load += nxt["load_l"]
            cur = nxt
        path = two_opt([depot] + trip + [depot])
        stops = path[1:-1]
        trips.append({
            "trip_no": len(trips) + 1,
            "stops": [
                {"id": s["id"], "name": s["name"], "lat": s["lat"], "lng": s["lng"],
                 "fill_level": s["fill_level"], "load_l": s["load_l"]}
                for s in stops
            ],
            "load_l": round(load, 1),
            "distance_km": round(path_length(path), 2),
            "path": [[n["lat"], n["lng"]] for n in path],
        })

    total = round(sum(t["distance_km"] for t in trips), 2)
    all_sorted = sorted(bins, key=lambda b: b["id"])
    baseline = round(path_length([depot] + all_sorted + [depot]), 2) if all_sorted else 0.0
    # Savings are only meaningful when a collection is actually planned.
    savings = round((baseline - total) / baseline * 100, 1) if (baseline > 0 and trips) else 0.0

    return {
        "threshold": threshold,
        "truck_capacity_l": truck_capacity_l,
        "bins_selected": selected_count,
        "bins_total": len(bins),
        "trips": trips,
        "total_distance_km": total,
        "baseline_distance_km": baseline,
        "savings_pct": max(savings, 0.0),
        "depot": depot,
    }
