"""Smart Waste Management - Flask backend (REST API + static dashboard).

Run locally:   python backend/app.py
Production:    gunicorn "app:create_app()"   (see Dockerfile)
"""
import hmac
import os
import random
from datetime import datetime, timedelta, timezone

from flask import Flask, jsonify, request

import database as db
from routing import DEPOT, optimize_routes

API_KEY = os.environ.get("API_KEY", "dev-key")
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")

OVERFLOW_AT = 90        # % fill that raises an OVERFLOW alert
CLEARED_BELOW = 50      # % fill at which an OVERFLOW alert auto-resolves
FIRE_AT = 60            # deg C that raises a FIRE alert
LOW_BATTERY_AT = 15     # % battery that raises a LOW_BATTERY alert
BATTERY_OK_ABOVE = 25   # % battery at which LOW_BATTERY resolves


# ----------------------------------------------------------------- helpers
def utcnow():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.isoformat(timespec="seconds")


def num(value, lo, hi):
    """Return float(value) if it is a finite number within [lo, hi], else None."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return None
    if v != v or not (lo <= v <= hi):
        return None
    return v


def bin_clock(row, hours=0.0):
    """A timestamp strictly after the bin's last reading (works with simulated time)."""
    base = utcnow()
    if row["last_seen"]:
        try:
            seen = datetime.fromisoformat(row["last_seen"])
            if seen > base:
                base = seen
        except ValueError:
            pass
    return iso(base + timedelta(hours=hours, seconds=1))


def open_alert(conn, bin_id, kind, message, ts):
    exists = conn.execute(
        "SELECT 1 FROM alerts WHERE bin_id=? AND type=? AND resolved=0", (bin_id, kind)
    ).fetchone()
    if not exists:
        conn.execute(
            "INSERT INTO alerts (bin_id, type, message, ts) VALUES (?,?,?,?)",
            (bin_id, kind, message, ts),
        )


def resolve_alerts(conn, bin_id, kinds):
    marks = ",".join("?" * len(kinds))
    conn.execute(
        f"UPDATE alerts SET resolved=1 WHERE bin_id=? AND resolved=0 AND type IN ({marks})",
        [bin_id, *kinds],
    )


def process_reading(conn, bin_id, fill, temp, battery, ts):
    """Store a reading, refresh the bin's current state and raise/clear alerts."""
    conn.execute(
        "UPDATE bins SET fill_level=?, temperature=?, battery=?, last_seen=? WHERE id=?",
        (fill, temp, battery, ts, bin_id),
    )
    conn.execute(
        "INSERT INTO readings (bin_id, fill_level, temperature, battery, ts) VALUES (?,?,?,?,?)",
        (bin_id, fill, temp, battery, ts),
    )
    if fill >= OVERFLOW_AT:
        open_alert(conn, bin_id, "OVERFLOW", f"Bin is {fill:.0f}% full - collect immediately", ts)
    elif fill < CLEARED_BELOW:
        resolve_alerts(conn, bin_id, ["OVERFLOW"])
    if temp >= FIRE_AT:
        open_alert(conn, bin_id, "FIRE", f"High temperature {temp:.0f} C - possible fire", ts)
    else:
        resolve_alerts(conn, bin_id, ["FIRE"])
    if battery <= LOW_BATTERY_AT:
        open_alert(conn, bin_id, "LOW_BATTERY", f"Sensor battery at {battery:.0f}%", ts)
    elif battery > BATTERY_OK_ABOVE:
        resolve_alerts(conn, bin_id, ["LOW_BATTERY"])


def predict_hours_to_full(conn, bin_id):
    """Linear estimate of hours until 100% using the latest filling cycle."""
    rows = conn.execute(
        "SELECT fill_level, ts FROM readings WHERE bin_id=? ORDER BY ts DESC, id DESC LIMIT 72",
        (bin_id,),
    ).fetchall()
    if len(rows) < 2:
        return None
    segment = [rows[0]]
    for r in rows[1:]:
        if r["fill_level"] > segment[-1]["fill_level"] + 0.5:
            break  # fill was higher earlier -> bin was emptied in between
        segment.append(r)
        if r["fill_level"] <= 0.5:
            break  # reached the moment of the last collection
    if len(segment) < 2:
        return None
    newest, oldest = segment[0], segment[-1]
    try:
        hours = (datetime.fromisoformat(newest["ts"]) - datetime.fromisoformat(oldest["ts"])
                 ).total_seconds() / 3600
    except ValueError:
        return None
    if hours <= 0:
        return None
    slope = (newest["fill_level"] - oldest["fill_level"]) / hours
    if slope <= 0.01:
        return None
    return round(max(0.0, 100 - newest["fill_level"]) / slope, 1)


def bin_to_dict(conn, row):
    d = dict(row)
    d.pop("sim_rate", None)
    d["volume_l"] = round(d["capacity_l"] * d["fill_level"] / 100, 1)
    d["status"] = ("critical" if d["fill_level"] >= 80
                   else "warning" if d["fill_level"] >= 50 else "ok")
    d["hours_to_full"] = predict_hours_to_full(conn, d["id"])
    return d


def authorized():
    supplied = request.headers.get("X-API-Key", "")
    return hmac.compare_digest(supplied.encode(), API_KEY.encode())


# ------------------------------------------------------------- app factory
def create_app(db_path=None, seed=True):
    if db_path:
        db.DB_PATH = db_path
    db.init_db()
    if seed and db.count_bins() == 0:
        db.seed_demo()

    app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")

    @app.get("/")
    def index():
        return app.send_static_file("index.html")

    @app.get("/api/health")
    def health():
        return jsonify(status="ok", time=iso(utcnow()))

    # ---- bins
    @app.get("/api/bins")
    def list_bins():
        with db.connect() as conn:
            rows = conn.execute("SELECT * FROM bins ORDER BY id").fetchall()
            return jsonify([bin_to_dict(conn, r) for r in rows])

    @app.post("/api/bins")
    def register_bin():
        if not authorized():
            return jsonify(error="invalid or missing API key"), 401
        data = request.get_json(silent=True) or {}
        bin_id = str(data.get("id", "")).strip()
        name = str(data.get("name", "")).strip()
        lat = num(data.get("lat"), -90, 90)
        lng = num(data.get("lng"), -180, 180)
        capacity = num(data.get("capacity_l", 1100), 1, 100000)
        if not bin_id or not name or lat is None or lng is None or capacity is None:
            return jsonify(error="id, name, lat, lng (and optional capacity_l) are required"), 400
        with db.connect() as conn:
            if conn.execute("SELECT 1 FROM bins WHERE id=?", (bin_id,)).fetchone():
                return jsonify(error="bin already exists"), 409
            conn.execute(
                "INSERT INTO bins (id, name, lat, lng, capacity_l, last_seen) VALUES (?,?,?,?,?,?)",
                (bin_id, name, lat, lng, capacity, iso(utcnow())),
            )
        return jsonify(id=bin_id, name=name), 201

    @app.get("/api/bins/<bin_id>/history")
    def history(bin_id):
        limit = int(num(request.args.get("limit", 48), 1, 500) or 48)
        with db.connect() as conn:
            if not conn.execute("SELECT 1 FROM bins WHERE id=?", (bin_id,)).fetchone():
                return jsonify(error="bin not found"), 404
            rows = conn.execute(
                "SELECT ts, fill_level, temperature, battery FROM readings"
                " WHERE bin_id=? ORDER BY ts DESC, id DESC LIMIT ?",
                (bin_id, limit),
            ).fetchall()
        return jsonify([dict(r) for r in reversed(rows)])

    # ---- telemetry from IoT devices
    @app.post("/api/telemetry")
    def telemetry():
        if not authorized():
            return jsonify(error="invalid or missing API key"), 401
        data = request.get_json(silent=True) or {}
        bin_id = data.get("bin_id")
        fill = num(data.get("fill_level"), 0, 100)
        temp = num(data.get("temperature", 25), -40, 125)
        battery = num(data.get("battery", 100), 0, 100)
        if not bin_id or fill is None or temp is None or battery is None:
            return jsonify(error="bin_id and fill_level (0-100) are required; "
                                 "temperature/battery must be in range"), 400
        raw_ts = data.get("timestamp")  # optional: gateways may upload buffered readings
        if raw_ts:
            try:
                dt = datetime.fromisoformat(str(raw_ts).replace("Z", "+00:00"))
            except ValueError:
                return jsonify(error="timestamp must be ISO-8601"), 400
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            ts = iso(dt.astimezone(timezone.utc))
        else:
            ts = iso(utcnow())
        with db.connect() as conn:
            if not conn.execute("SELECT 1 FROM bins WHERE id=?", (bin_id,)).fetchone():
                return jsonify(error="unknown bin_id"), 404
            process_reading(conn, bin_id, fill, temp, battery, ts)
        return jsonify(status="stored", bin_id=bin_id, ts=ts), 201

    # ---- alerts, stats
    @app.get("/api/alerts")
    def alerts():
        status = request.args.get("status", "open")
        where = "WHERE a.resolved=0" if status == "open" else ""
        with db.connect() as conn:
            rows = conn.execute(
                "SELECT a.id, a.bin_id, b.name AS bin_name, a.type, a.message, a.ts, a.resolved"
                f" FROM alerts a JOIN bins b ON b.id=a.bin_id {where}"
                " ORDER BY a.ts DESC, a.id DESC LIMIT 100"
            ).fetchall()
        return jsonify([dict(r) for r in rows])

    @app.get("/api/stats")
    def stats():
        with db.connect() as conn:
            rows = conn.execute("SELECT * FROM bins").fetchall()
            open_alerts = conn.execute(
                "SELECT COUNT(*) FROM alerts WHERE resolved=0").fetchone()[0]
        n = len(rows)
        return jsonify(
            total_bins=n,
            average_fill=round(sum(r["fill_level"] for r in rows) / n, 1) if n else 0,
            critical_bins=sum(1 for r in rows if r["fill_level"] >= 80),
            open_alerts=open_alerts,
            average_battery=round(sum(r["battery"] for r in rows) / n, 1) if n else 0,
            waste_volume_l=round(sum(r["capacity_l"] * r["fill_level"] / 100 for r in rows), 1),
        )

    # ---- route optimization
    @app.get("/api/route")
    def route():
        threshold = num(request.args.get("threshold", 70), 0, 100)
        capacity = num(request.args.get("capacity", 6000), 100, 100000)
        if threshold is None or capacity is None:
            return jsonify(error="threshold must be 0-100 and capacity 100-100000"), 400
        with db.connect() as conn:
            rows = [dict(r) for r in conn.execute("SELECT * FROM bins").fetchall()]
        return jsonify(optimize_routes(rows, threshold, capacity, DEPOT))

    # ---- collection (truck emptied the bin)
    def collect_bins(ids):
        done = []
        with db.connect() as conn:
            for bin_id in ids:
                row = conn.execute("SELECT * FROM bins WHERE id=?", (bin_id,)).fetchone()
                if row:
                    process_reading(conn, bin_id, 0.0, row["temperature"], row["battery"],
                                    bin_clock(row))
                    done.append(bin_id)
        return done

    @app.post("/api/bins/<bin_id>/collect")
    def collect_one(bin_id):
        done = collect_bins([bin_id])
        if not done:
            return jsonify(error="bin not found"), 404
        return jsonify(collected=done)

    @app.post("/api/collect")
    def collect_many():
        data = request.get_json(silent=True) or {}
        ids = data.get("bin_ids")
        if not isinstance(ids, list) or not ids:
            return jsonify(error="bin_ids must be a non-empty list"), 400
        return jsonify(collected=collect_bins([str(i) for i in ids]))

    # ---- demo helpers
    @app.post("/api/simulate/step")
    def simulate_step():
        data = request.get_json(silent=True) or {}
        hours = num(data.get("hours", 1), 0.1, 48)
        if hours is None:
            return jsonify(error="hours must be 0.1-48"), 400
        rng = random.Random()
        with db.connect() as conn:
            for r in conn.execute("SELECT * FROM bins").fetchall():
                fill = min(100.0, r["fill_level"] + r["sim_rate"] * hours * rng.uniform(0.7, 1.3))
                temp = min(45.0, max(20.0, r["temperature"] + rng.uniform(-1, 1)))
                battery = max(0.0, r["battery"] - 0.05 * hours)
                process_reading(conn, r["id"], round(fill, 1), round(temp, 1),
                                round(battery, 1), bin_clock(r, hours))
        return jsonify(status="advanced", hours=hours)

    @app.post("/api/seed")
    def reseed():
        db.reset_and_seed()
        return jsonify(status="reset", bins=db.count_bins())

    return app


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    create_app().run(host="0.0.0.0", port=port, debug=os.environ.get("FLASK_DEBUG") == "1")
