HDR = {"X-API-Key": "dev-key"}


def register(client, bin_id="T-1", **overrides):
    payload = {"id": bin_id, "name": "Test bin", "lat": 13.05, "lng": 80.25, "capacity_l": 1000}
    payload.update(overrides)
    return client.post("/api/bins", json=payload, headers=HDR)


def send(client, bin_id="T-1", **fields):
    payload = {"bin_id": bin_id, "fill_level": 40, "temperature": 28, "battery": 90}
    payload.update(fields)
    return client.post("/api/telemetry", json=payload, headers=HDR)


def alert_types(client):
    return {a["type"] for a in client.get("/api/alerts").get_json()}


def test_health(client):
    assert client.get("/api/health").get_json()["status"] == "ok"


def test_seeded_database_has_24_bins(seeded_client):
    bins = seeded_client.get("/api/bins").get_json()
    assert len(bins) == 24
    assert {"id", "name", "fill_level", "volume_l", "status", "hours_to_full"} <= set(bins[0])


def test_register_bin_requires_api_key(client):
    r = client.post("/api/bins", json={"id": "X", "name": "x", "lat": 1, "lng": 1})
    assert r.status_code == 401


def test_register_bin_and_reject_duplicate(client):
    assert register(client).status_code == 201
    assert register(client).status_code == 409
    assert register(client, bin_id="T-2", lat=999).status_code == 400


def test_telemetry_requires_api_key(client):
    register(client)
    r = client.post("/api/telemetry", json={"bin_id": "T-1", "fill_level": 10})
    assert r.status_code == 401
    r = client.post("/api/telemetry", json={"bin_id": "T-1", "fill_level": 10},
                    headers={"X-API-Key": "wrong"})
    assert r.status_code == 401


def test_telemetry_validation(client):
    register(client)
    assert send(client, fill_level=150).status_code == 400
    assert send(client, fill_level="abc").status_code == 400
    assert send(client, battery=-5).status_code == 400
    assert send(client, timestamp="not-a-date").status_code == 400
    assert send(client, bin_id="NOPE").status_code == 404


def test_telemetry_updates_bin_and_history(client):
    register(client)
    assert send(client, fill_level=42.5).status_code == 201
    bins = client.get("/api/bins").get_json()
    assert bins[0]["fill_level"] == 42.5 and bins[0]["volume_l"] == 425
    history = client.get("/api/bins/T-1/history").get_json()
    assert history[-1]["fill_level"] == 42.5
    assert client.get("/api/bins/NOPE/history").status_code == 404


def test_overflow_alert_raised_once_and_auto_resolved(client):
    register(client)
    send(client, fill_level=95)
    send(client, fill_level=97)
    alerts = client.get("/api/alerts").get_json()
    assert [a["type"] for a in alerts] == ["OVERFLOW"]  # no duplicate
    send(client, fill_level=10)
    assert client.get("/api/alerts").get_json() == []


def test_fire_and_low_battery_alerts(client):
    register(client)
    send(client, temperature=75, battery=8)
    assert alert_types(client) == {"FIRE", "LOW_BATTERY"}
    send(client, temperature=30, battery=90)
    assert alert_types(client) == set()


def test_collect_resets_bin_and_resolves_alerts(client):
    register(client)
    send(client, fill_level=96)
    assert "OVERFLOW" in alert_types(client)
    assert client.post("/api/bins/T-1/collect").status_code == 200
    assert client.get("/api/bins").get_json()[0]["fill_level"] == 0
    assert alert_types(client) == set()
    assert client.post("/api/bins/NOPE/collect").status_code == 404


def test_bulk_collect_validation(client):
    register(client)
    assert client.post("/api/collect", json={}).status_code == 400
    r = client.post("/api/collect", json={"bin_ids": ["T-1", "GHOST"]})
    assert r.get_json()["collected"] == ["T-1"]


def test_route_endpoint_only_returns_full_bins(seeded_client):
    r = seeded_client.get("/api/route?threshold=80&capacity=4000").get_json()
    assert r["threshold"] == 80
    for trip in r["trips"]:
        assert trip["load_l"] <= 4000 or len(trip["stops"]) == 1
        for stop in trip["stops"]:
            assert stop["fill_level"] >= 80
    assert r["total_distance_km"] <= r["baseline_distance_km"]


def test_route_rejects_bad_parameters(seeded_client):
    assert seeded_client.get("/api/route?threshold=500").status_code == 400
    assert seeded_client.get("/api/route?capacity=abc").status_code == 400


def test_stats(seeded_client):
    s = seeded_client.get("/api/stats").get_json()
    assert s["total_bins"] == 24
    assert 0 <= s["average_fill"] <= 100
    assert {"critical_bins", "open_alerts", "average_battery", "waste_volume_l"} <= set(s)


def test_simulation_step_raises_fill_levels(seeded_client):
    before = {b["id"]: b["fill_level"] for b in seeded_client.get("/api/bins").get_json()}
    assert seeded_client.post("/api/simulate/step", json={"hours": 3}).status_code == 200
    after = {b["id"]: b["fill_level"] for b in seeded_client.get("/api/bins").get_json()}
    assert all(after[i] >= before[i] for i in before)
    assert any(after[i] > before[i] for i in before)


def test_prediction_from_steady_fill_rate(client):
    register(client)
    for hour, fill in enumerate([10, 20, 30, 40]):
        send(client, fill_level=fill, timestamp=f"2026-11-01T0{hour}:00:00+00:00")
    bin_ = client.get("/api/bins").get_json()[0]
    assert bin_["hours_to_full"] == 6.0  # 10 %/h, 60 % left


def test_dashboard_is_served(client):
    r = client.get("/")
    assert r.status_code == 200 and b"SmartBin Cloud" in r.data
