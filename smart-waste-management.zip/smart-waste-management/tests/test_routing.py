import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "backend"))

from routing import DEPOT, haversine_km, optimize_routes, path_length, two_opt  # noqa: E402


def mk(i, lat, lng, fill, cap=1000):
    return {"id": f"B{i}", "name": f"Bin {i}", "lat": lat, "lng": lng,
            "fill_level": fill, "capacity_l": cap}


def test_haversine_chennai_to_bengaluru():
    d = haversine_km((13.0827, 80.2707), (12.9716, 77.5946))
    assert 280 < d < 300


def test_haversine_zero_distance():
    assert haversine_km((13.0, 80.0), (13.0, 80.0)) == 0


def test_only_bins_above_threshold_are_collected():
    bins = [mk(1, 13.05, 80.25, 90), mk(2, 13.06, 80.26, 20), mk(3, 13.07, 80.27, 75)]
    result = optimize_routes(bins, threshold=70)
    ids = {s["id"] for t in result["trips"] for s in t["stops"]}
    assert ids == {"B1", "B3"}
    assert result["bins_selected"] == 2 and result["bins_total"] == 3


def test_truck_capacity_is_respected():
    bins = [mk(i, 13.0 + i * 0.01, 80.2 + i * 0.01, 100) for i in range(6)]  # 1000 L each
    result = optimize_routes(bins, threshold=70, truck_capacity_l=2500)
    assert len(result["trips"]) == 3
    assert all(t["load_l"] <= 2500 for t in result["trips"])
    assert sum(len(t["stops"]) for t in result["trips"]) == 6


def test_oversized_bin_still_gets_its_own_trip():
    result = optimize_routes([mk(1, 13.05, 80.25, 100, cap=5000)], threshold=70, truck_capacity_l=1000)
    assert len(result["trips"]) == 1 and len(result["trips"][0]["stops"]) == 1


def test_two_opt_never_makes_route_longer():
    rng = random.Random(7)
    pts = [{"lat": 13.0 + rng.random() * 0.1, "lng": 80.2 + rng.random() * 0.1} for _ in range(9)]
    path = [DEPOT] + pts + [DEPOT]
    improved = two_opt(path)
    assert path_length(improved) <= path_length(path) + 1e-9
    assert improved[0] is DEPOT and improved[-1] is DEPOT
    assert len(improved) == len(path)


def test_no_bins_above_threshold_gives_empty_plan():
    result = optimize_routes([mk(1, 13.05, 80.25, 10)], threshold=70)
    assert result["trips"] == [] and result["total_distance_km"] == 0
    assert result["savings_pct"] == 0


def test_smart_route_saves_distance_versus_fixed_route():
    bins = [mk(i, 13.0 + i * 0.01, 80.2 + (i % 3) * 0.02, 10) for i in range(10)]
    for b in bins[:3]:
        b["fill_level"] = 95
    result = optimize_routes(bins, threshold=70, truck_capacity_l=6000)
    assert result["savings_pct"] > 0
    assert result["total_distance_km"] < result["baseline_distance_km"]
