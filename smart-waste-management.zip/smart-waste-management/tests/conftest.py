import os
import sys

os.environ["API_KEY"] = "dev-key"
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "backend"))

import pytest  # noqa: E402

from app import create_app  # noqa: E402


@pytest.fixture
def client(tmp_path):
    """Empty database - tests register their own bins."""
    app = create_app(db_path=str(tmp_path / "test.db"), seed=False)
    app.config["TESTING"] = True
    return app.test_client()


@pytest.fixture
def seeded_client(tmp_path):
    """Database pre-loaded with the 24 demo bins."""
    app = create_app(db_path=str(tmp_path / "seeded.db"), seed=True)
    app.config["TESTING"] = True
    return app.test_client()
