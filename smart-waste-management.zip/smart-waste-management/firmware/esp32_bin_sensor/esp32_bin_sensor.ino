/*
 * Smart Bin Node - ESP32 firmware
 * ------------------------------------------------------------------
 * Measures bin fill level (HC-SR04 ultrasonic, mounted under the lid),
 * internal temperature (DHT22) and battery voltage, then uploads a JSON
 * reading to the cloud API over Wi-Fi and goes to deep sleep.
 *
 * Wiring (ESP32 DevKit v1)
 *   HC-SR04  VCC -> 5V   GND -> GND   TRIG -> GPIO 5   ECHO -> GPIO 18 (through a 1k/2k divider to 3.3V)
 *   DHT22    VCC -> 3V3  GND -> GND   DATA -> GPIO 4   (10k pull-up to 3V3)
 *   Battery  Li-ion + -> 100k -> GPIO 34 -> 100k -> GND   (1:1 divider)
 *
 * Libraries: "DHT sensor library" by Adafruit (+ Adafruit Unified Sensor)
 * Board:     "ESP32 Dev Module"
 *
 * For production use HTTPS (WiFiClientSecure) and keep the API key out of source control.
 */
#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>

// ---------------------------- configuration ----------------------------
const char* WIFI_SSID   = "YOUR_WIFI_SSID";
const char* WIFI_PASS   = "YOUR_WIFI_PASSWORD";
const char* SERVER_URL  = "http://192.168.1.50:5000/api/telemetry";  // cloud API endpoint
const char* API_KEY     = "dev-key";                                  // matches API_KEY on the server
const char* BIN_ID      = "BIN-001";                                  // must be registered on the server

const float BIN_HEIGHT_CM     = 100.0;  // sensor face to empty bin floor
const float SENSOR_DEADZONE_CM = 5.0;   // HC-SR04 cannot measure closer than ~2-5 cm
const uint32_t SLEEP_MINUTES  = 15;     // upload interval

const int PIN_TRIG = 5;
const int PIN_ECHO = 18;
const int PIN_DHT  = 4;
const int PIN_BAT  = 34;
#define DHT_TYPE DHT22
// -----------------------------------------------------------------------

DHT dht(PIN_DHT, DHT_TYPE);

float readDistanceOnceCm() {
  digitalWrite(PIN_TRIG, LOW);  delayMicroseconds(3);
  digitalWrite(PIN_TRIG, HIGH); delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  unsigned long us = pulseIn(PIN_ECHO, HIGH, 30000UL);  // 30 ms timeout (~5 m)
  if (us == 0) return -1;                                // no echo
  return us * 0.0343f / 2.0f;
}

// Median of 7 samples rejects spikes caused by crumpled waste or splashes.
float readDistanceCm() {
  float s[7];
  int n = 0;
  for (int i = 0; i < 7; i++) {
    float d = readDistanceOnceCm();
    if (d > 0) s[n++] = d;
    delay(60);
  }
  if (n == 0) return -1;
  for (int i = 1; i < n; i++) {                          // insertion sort
    float key = s[i]; int j = i - 1;
    while (j >= 0 && s[j] > key) { s[j + 1] = s[j]; j--; }
    s[j + 1] = key;
  }
  return s[n / 2];
}

float fillPercent(float distanceCm) {
  float usable = BIN_HEIGHT_CM - SENSOR_DEADZONE_CM;
  float pct = (BIN_HEIGHT_CM - distanceCm) / usable * 100.0f;
  if (pct < 0) pct = 0;
  if (pct > 100) pct = 100;
  return pct;
}

float batteryPercent() {
  float volts = analogReadMilliVolts(PIN_BAT) * 2.0f / 1000.0f;  // undo 1:1 divider
  float pct = (volts - 3.3f) / (4.2f - 3.3f) * 100.0f;           // Li-ion 3.3 V empty .. 4.2 V full
  if (pct < 0) pct = 0;
  if (pct > 100) pct = 100;
  return pct;
}

bool connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) delay(250);
  return WiFi.status() == WL_CONNECTED;
}

bool postReading(float fill, float temp, float battery) {
  char body[160];
  snprintf(body, sizeof(body),
           "{\"bin_id\":\"%s\",\"fill_level\":%.1f,\"temperature\":%.1f,\"battery\":%.1f}",
           BIN_ID, fill, temp, battery);
  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-API-Key", API_KEY);
  int code = http.POST((uint8_t*)body, strlen(body));
  http.end();
  Serial.printf("POST %s -> HTTP %d\n", body, code);
  return code == 201;
}

void goToSleep() {
  Serial.printf("Sleeping for %u minutes\n", SLEEP_MINUTES);
  WiFi.disconnect(true);
  esp_sleep_enable_timer_wakeup((uint64_t)SLEEP_MINUTES * 60ULL * 1000000ULL);
  esp_deep_sleep_start();
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  dht.begin();
  delay(2000);  // DHT22 warm-up

  float dist = readDistanceCm();
  float temp = dht.readTemperature();
  if (isnan(temp)) temp = 25.0f;  // fall back if the DHT read fails
  float battery = batteryPercent();

  if (dist < 0) {
    Serial.println("Ultrasonic sensor: no echo - skipping upload");
  } else if (connectWifi()) {
    postReading(fillPercent(dist), temp, battery);
  } else {
    Serial.println("Wi-Fi unavailable - will retry next cycle");
  }
  goToSleep();
}

void loop() {}  // never reached: the device deep-sleeps at the end of setup()
