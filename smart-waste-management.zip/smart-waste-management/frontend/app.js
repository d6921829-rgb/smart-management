(() => {
  "use strict";

  const TRIP_COLORS = ["#2563eb", "#db2777", "#7c3aed", "#ea580c", "#0d9488", "#ca8a04"];
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const levelColor = (f) => (f >= 80 ? "#dc2626" : f >= 50 ? "#f59e0b" : "#16a34a");
  const fmtTime = (iso) =>
    new Date(iso).toLocaleString([], { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
  const fmtHours = (h) => (h == null ? "-" : h < 1 ? "<1 h" : h > 99 ? "99+ h" : `${h.toFixed(1)} h`);

  // ------------------------------------------------------------- map setup
  const map = L.map("map").setView([13.06, 80.25], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);
  const binLayer = L.layerGroup().addTo(map);
  const routeLayer = L.layerGroup().addTo(map);

  const markers = {};
  let bins = [];
  let selectedId = null;
  let currentRoute = null;
  let chart = null;

  // ------------------------------------------------------------- API utils
  async function api(path, options) {
    const res = await fetch(path, options);
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(body.error || res.statusText);
    return body;
  }
  const post = (path, body) =>
    api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });

  let toastTimer;
  function toast(msg) {
    const el = $("toast");
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 3000);
  }

  // ------------------------------------------------------------- rendering
  function renderStats(s) {
    $("stBins").textContent = s.total_bins;
    $("stFill").textContent = `${s.average_fill}%`;
    $("stCritical").textContent = s.critical_bins;
    $("stAlerts").textContent = s.open_alerts;
    $("stVolume").textContent = `${Math.round(s.waste_volume_l).toLocaleString()} L`;
    $("stBattery").textContent = `${s.average_battery}%`;
  }

  function popupHtml(b) {
    return `<div class="popup"><b>${esc(b.name)}</b><div class="muted small">${esc(b.id)}</div>
      <div class="row"><span>Fill level</span><b>${b.fill_level}%</b></div>
      <div class="row"><span>Volume</span><span>${b.volume_l} / ${b.capacity_l} L</span></div>
      <div class="row"><span>Temperature</span><span>${b.temperature} &deg;C</span></div>
      <div class="row"><span>Battery</span><span>${b.battery}%</span></div>
      <div class="row"><span>Full in</span><span>${fmtHours(b.hours_to_full)}</span></div>
      <div class="row"><span>Last seen</span><span>${b.last_seen ? fmtTime(b.last_seen) : "-"}</span></div>
      <button data-collect="${esc(b.id)}">Mark as collected</button></div>`;
  }

  function renderMarkers() {
    const seen = new Set();
    bins.forEach((b) => {
      seen.add(b.id);
      const style = {
        radius: 8 + b.fill_level / 18, color: "#ffffff", weight: 2,
        fillColor: levelColor(b.fill_level), fillOpacity: 0.95,
      };
      let m = markers[b.id];
      if (!m) {
        m = L.circleMarker([b.lat, b.lng], style).addTo(binLayer);
        m.on("click", () => selectBin(b.id, false));
        markers[b.id] = m;
      } else {
        m.setStyle(style);
      }
      if (m.getPopup()) m.setPopupContent(popupHtml(b));
      else m.bindPopup(popupHtml(b));
    });
    Object.keys(markers).forEach((id) => {
      if (!seen.has(id)) { binLayer.removeLayer(markers[id]); delete markers[id]; }
    });
  }

  function renderTable() {
    const rows = [...bins].sort((a, b) => b.fill_level - a.fill_level);
    $("binRows").innerHTML = rows.map((b) => `
      <tr data-id="${esc(b.id)}" class="${b.id === selectedId ? "sel" : ""}">
        <td>${esc(b.name)}<div class="muted small">${esc(b.id)}</div></td>
        <td><span class="meter"><i style="width:${b.fill_level}%;background:${levelColor(b.fill_level)}"></i></span>${b.fill_level}%</td>
        <td>${fmtHours(b.hours_to_full)}</td>
        <td>${b.battery}%</td>
      </tr>`).join("");
  }

  function renderAlerts(list) {
    $("alertList").innerHTML = list.length
      ? list.map((a) => `<li><span class="badge ${esc(a.type)}">${esc(a.type.replace("_", " "))}</span>
          <div><b>${esc(a.bin_name)}</b><div class="small muted">${esc(a.message)} &middot; ${fmtTime(a.ts)}</div></div></li>`).join("")
      : '<li class="muted">No open alerts.</li>';
  }

  async function drawHistory(id) {
    const h = await api(`/api/bins/${encodeURIComponent(id)}/history?limit=48`);
    const b = bins.find((x) => x.id === id);
    $("selectedTitle").textContent = b ? `Fill history - ${b.name}` : "Fill history";
    $("selectedHint").textContent = b ? `Predicted to be full in ${fmtHours(b.hours_to_full)}.` : "";
    if (chart) chart.destroy();
    chart = new Chart($("historyChart").getContext("2d"), {
      type: "line",
      data: {
        labels: h.map((r) => fmtTime(r.ts)),
        datasets: [{
          label: "Fill %", data: h.map((r) => r.fill_level), borderColor: "#16a34a",
          backgroundColor: "rgba(22,163,74,.12)", fill: true, tension: 0.25, pointRadius: 0,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { min: 0, max: 100 }, x: { ticks: { maxTicksLimit: 5 } } },
      },
    });
  }

  function selectBin(id, fly = true) {
    selectedId = id;
    const b = bins.find((x) => x.id === id);
    if (b && fly) { map.flyTo([b.lat, b.lng], 14); markers[id] && markers[id].openPopup(); }
    renderTable();
    drawHistory(id).catch((e) => toast(e.message));
  }

  // --------------------------------------------------------------- routing
  function drawRoute(r) {
    routeLayer.clearLayers();
    const summary = $("routeSummary");
    if (!r.trips.length) {
      summary.innerHTML = `<p class="muted">No bins are at or above ${r.threshold}% - no collection needed.</p>`;
      return;
    }
    L.marker([r.depot.lat, r.depot.lng], {
      icon: L.divIcon({ className: "", html: '<div class="depot-pin">D</div>', iconSize: [26, 26] }),
    }).bindTooltip(esc(r.depot.name)).addTo(routeLayer);

    r.trips.forEach((t, i) => {
      const color = TRIP_COLORS[i % TRIP_COLORS.length];
      L.polyline(t.path, { color, weight: 4, opacity: 0.85 }).addTo(routeLayer);
      t.stops.forEach((s, j) => {
        L.marker([s.lat, s.lng], {
          icon: L.divIcon({
            className: "", iconSize: [22, 22],
            html: `<div class="stop-pin" style="background:${color}">${j + 1}</div>`,
          }),
        }).bindTooltip(`Trip ${t.trip_no}, stop ${j + 1}: ${esc(s.name)} (${s.fill_level}%)`).addTo(routeLayer);
      });
    });

    summary.innerHTML = `
      <div class="kpis">
        <div><b>${r.bins_selected} / ${r.bins_total}</b>bins to collect</div>
        <div><b>${r.trips.length}</b>truck trip(s)</div>
        <div><b>${r.total_distance_km} km</b>optimized distance</div>
        <div><b class="good">${r.savings_pct}%</b>saved vs fixed route (${r.baseline_distance_km} km)</div>
      </div>
      <ol class="trips">${r.trips.map((t, i) => `<li><span class="trip-dot" style="background:${TRIP_COLORS[i % TRIP_COLORS.length]}"></span>
        ${t.stops.length} stops &middot; ${t.distance_km} km &middot; ${Math.round(t.load_l).toLocaleString()} L</li>`).join("")}</ol>
      <button id="btnCollectRoute" class="btn warn">Mark this route as collected</button>`;
    map.fitBounds(L.latLngBounds(r.trips.flatMap((t) => t.path)).pad(0.1));
  }

  async function optimize() {
    try {
      currentRoute = await api(`/api/route?threshold=${$("threshold").value}&capacity=${$("capacity").value}`);
      drawRoute(currentRoute);
    } catch (e) { toast(e.message); }
  }

  function clearRoute() {
    currentRoute = null;
    routeLayer.clearLayers();
    $("routeSummary").innerHTML = "";
  }

  // ----------------------------------------------------------------- data
  async function refresh() {
    try {
      const [b, s, a] = await Promise.all([api("/api/bins"), api("/api/stats"), api("/api/alerts")]);
      bins = b;
      renderStats(s); renderMarkers(); renderTable(); renderAlerts(a);
    } catch (e) { toast(`Cannot reach server: ${e.message}`); }
  }

  async function simulate(hours) {
    try {
      await post("/api/simulate/step", { hours });
      clearRoute();
      await refresh();
      if (selectedId) drawHistory(selectedId);
      toast(`Advanced demo clock by ${hours} h`);
    } catch (e) { toast(e.message); }
  }

  async function collect(ids) {
    try {
      await post("/api/collect", { bin_ids: ids });
      clearRoute();
      await refresh();
      if (selectedId) drawHistory(selectedId);
      toast(`${ids.length} bin(s) marked as collected`);
    } catch (e) { toast(e.message); }
  }

  // --------------------------------------------------------------- events
  $("threshold").addEventListener("input", (e) => { $("thLabel").textContent = e.target.value; });
  $("btnRoute").addEventListener("click", optimize);
  $("btnSim1").addEventListener("click", () => simulate(1));
  $("btnSim6").addEventListener("click", () => simulate(6));
  $("btnReset").addEventListener("click", async () => {
    try { await post("/api/seed"); clearRoute(); selectedId = null; await refresh(); toast("Demo data reset"); }
    catch (e) { toast(e.message); }
  });
  $("binRows").addEventListener("click", (e) => {
    const tr = e.target.closest("tr[data-id]");
    if (tr) selectBin(tr.dataset.id);
  });
  document.addEventListener("click", (e) => {
    const single = e.target.closest("[data-collect]");
    if (single) { collect([single.dataset.collect]); map.closePopup(); return; }
    if (e.target.id === "btnCollectRoute" && currentRoute) {
      collect(currentRoute.trips.flatMap((t) => t.stops.map((s) => s.id)));
    }
  });

  refresh();
  setInterval(refresh, 10000);
})();
